# NiveshRaksha source reference

This app recreates the user-confirmed live NiveshRaksha site. Its published
GitHub repository was empty, so the working client bundle, styles, PWA
manifest, service worker, icons, and favicon were captured from the supplied
live site.

## Product and visual language

NiveshRaksha is a local-first investor safety companion for Indian first-time
and retail investors. It helps people pause before trusting financial
messages, understand investor safety, and prepare their own next steps. It is
educational: it does not provide stock tips, predict returns, or submit
complaints.

The published UI uses DM Sans for body text and Manrope for headings. Its
palette is built around forest green, warm ivory, sage surfaces, and amber
accents. It is designed to work without an account or a connection to financial
services.

## Routes

- `/` — Home and entry points to the safety tools.
- `/check` — Local, explainable screening of text messages and claims.
- `/learn` — Searchable safety topics in English, Hindi, and Kannada.
- `/simulator` — Fictional learning scenarios; no real money or predictions.
- `/journal` — Private reflection prompts stored in the browser.
- `/rights` — Investor rights and official support links.
- `/dashboard` — Local progress, saved risk checks, learning topics, and journal
  counts.
- `/screenshot` — Local image preview plus manual text entry; no OCR upload.
- `/content-checker` — Local assessment of financial promotional/educational
  language.
- `/grievance` — Editable complaint draft, copied or downloaded locally; never
  submitted by the app.
- `/checklist` — Nine safety habits with browser-local progress.
- `/privacy` — Data handling explanation and local data clearing.
- `/about` — Trust boundaries, automation limits, and service disclaimer.

## Data and safety behavior

The original site is client-only. Personal journal entries, checklist progress,
saved learning topics, and saved incidents remain in browser local storage.
The message and content checkers use deterministic browser-side word-pattern
rules and present signals rather than verdicts. Do not add accounts, remote
analysis, financial-service connections, or automatic complaint submission.

All routes share a responsive navigation shell. The original production assets
are in `public/assets/`; the manifest, service worker, icons, and favicon are
also local in `public/`.