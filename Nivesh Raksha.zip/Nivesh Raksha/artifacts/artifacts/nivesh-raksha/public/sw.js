const CACHE_NAME = 'nivesh-raksha-shell-v1';
const SCOPE_URL = new URL(self.registration.scope);
const APP_URL = new URL('./', SCOPE_URL).href;
const CORE_URLS = [
  APP_URL,
  new URL('manifest.webmanifest', SCOPE_URL).href,
  new URL('favicon.svg', SCOPE_URL).href,
  new URL('icons/icon-192.png', SCOPE_URL).href,
  new URL('icons/icon-512.png', SCOPE_URL).href,
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      const response = await fetch(APP_URL, { cache: 'reload' });
      if (!response.ok) throw new Error('The app shell could not be downloaded.');
      await cache.put(APP_URL, response.clone());

      const html = await response.text();
      const bundledAssets = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/g)]
        .map((match) => new URL(match[1], APP_URL).href)
        .filter((url) => {
          const asset = new URL(url);
          return (
            asset.origin === self.location.origin &&
            asset.pathname.startsWith(new URL('assets/', SCOPE_URL).pathname)
          );
        });

      await Promise.all(
        [...new Set([...CORE_URLS, ...bundledAssets])].map(async (url) => {
          try {
            const asset = await fetch(url, { cache: 'reload' });
            if (asset.ok) await cache.put(url, asset);
          } catch {
            // Keep installing if an optional icon or asset is temporarily unavailable.
          }
        }),
      );
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((key) => key.startsWith('nivesh-raksha-') && key !== CACHE_NAME)
          .map((key) => caches.delete(key)),
      );
      await self.clients.claim();
    })(),
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api') || url.pathname.includes('/@vite')) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const response = await fetch(request);
          if (response.ok) {
            const cache = await caches.open(CACHE_NAME);
            await cache.put(APP_URL, response.clone());
          }
          return response;
        } catch {
          return (await caches.match(APP_URL)) || Response.error();
        }
      })(),
    );
    return;
  }

  const isStaticAppAsset =
    url.pathname.startsWith(new URL('assets/', SCOPE_URL).pathname) ||
    url.pathname.startsWith(new URL('icons/', SCOPE_URL).pathname) ||
    url.pathname.endsWith('.webmanifest') ||
    url.pathname.endsWith('.svg');
  if (!isStaticAppAsset) return;

  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request);
      if (cached) return cached;
      try {
        const response = await fetch(request);
        if (response.ok) await cache.put(request, response.clone());
        return response;
      } catch {
        return Response.error();
      }
    })(),
  );
});